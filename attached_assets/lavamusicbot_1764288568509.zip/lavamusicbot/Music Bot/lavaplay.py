import discord
import wavelink
import sqlite3
import os
import logging
import asyncio
import aiohttp 
import random
import json
import time
from discord.ext import commands
from typing import Optional, cast, Dict
from dotenv import load_dotenv

# --- Configuration & Setup ---
load_dotenv()
TOKEN = os.getenv("DISCORD_TOKEN")
LAVALINK_URI = os.getenv("LAVALINK_URI", "http://127.0.0.1:2333")
LAVALINK_PASS = os.getenv("LAVALINK_PASS", "youshallnotpass")
LAVALINK_IDENTIFIER = os.getenv("LAVALINK_ID", "main_node")

# Configure Logging
logging.basicConfig(level=logging.INFO)
logger = logging.getLogger("LavaPlay")

# --- Database Manager (SQLite) ---
class DatabaseManager:
    def __init__(self, db_name="bot_settings.db"):
        self.db_name = db_name
        self._init_db()

    def _init_db(self):
        with sqlite3.connect(self.db_name) as conn:
            cursor = conn.cursor()
            cursor.execute("""
                CREATE TABLE IF NOT EXISTS prefixes (
                    guild_id INTEGER PRIMARY KEY,
                    prefix TEXT NOT NULL
                )
            """)
            cursor.execute("""
                CREATE TABLE IF NOT EXISTS settings_247 (
                    guild_id INTEGER PRIMARY KEY,
                    is_enabled BOOLEAN DEFAULT 0
                )
            """)
            conn.commit()

    def get_prefix(self, guild_id: int) -> str:
        with sqlite3.connect(self.db_name) as conn:
            cursor = conn.cursor()
            cursor.execute("SELECT prefix FROM prefixes WHERE guild_id = ?", (guild_id,))
            result = cursor.fetchone()
            return result[0] if result else "m!"

    def set_prefix(self, guild_id: int, new_prefix: str):
        with sqlite3.connect(self.db_name) as conn:
            cursor = conn.cursor()
            cursor.execute("""
                INSERT INTO prefixes (guild_id, prefix) VALUES (?, ?)
                ON CONFLICT(guild_id) DO UPDATE SET prefix = excluded.prefix
            """, (guild_id, new_prefix))
            conn.commit()

    def get_247_status(self, guild_id: int) -> bool:
        with sqlite3.connect(self.db_name) as conn:
            cursor = conn.cursor()
            cursor.execute("SELECT is_enabled FROM settings_247 WHERE guild_id = ?", (guild_id,))
            result = cursor.fetchone()
            return bool(result[0]) if result else False

    def set_247_status(self, guild_id: int, status: bool):
        with sqlite3.connect(self.db_name) as conn:
            cursor = conn.cursor()
            cursor.execute("""
                INSERT INTO settings_247 (guild_id, is_enabled) VALUES (?, ?)
                ON CONFLICT(guild_id) DO UPDATE SET is_enabled = excluded.is_enabled
            """, (guild_id, int(status)))
            conn.commit()

db = DatabaseManager()

# --- TRIVIA UI CLASSES ---

class GameSelectionView(discord.ui.View):
    def __init__(self, ctx):
        super().__init__(timeout=60)
        self.ctx = ctx
        self.value = None

    @discord.ui.button(label="🎵 Guess the Song", style=discord.ButtonStyle.primary, emoji="🎼")
    async def song_trivia(self, interaction: discord.Interaction, button: discord.ui.Button):
        if interaction.user.id != self.ctx.author.id:
            return await interaction.response.send_message("❌ Only the host can choose.", ephemeral=True)
        self.value = "song"
        self.stop()
        await interaction.response.defer()

    @discord.ui.button(label="🎬 Guess the Movie (Bollywood)", style=discord.ButtonStyle.success, emoji="🎥")
    async def movie_trivia(self, interaction: discord.Interaction, button: discord.ui.Button):
        if interaction.user.id != self.ctx.author.id:
            return await interaction.response.send_message("❌ Only the host can choose.", ephemeral=True)
        self.value = "movie"
        self.stop()
        await interaction.response.defer()

class TriviaVoteView(discord.ui.View):
    def __init__(self, host_id, participants):
        super().__init__(timeout=60)
        self.host_id = host_id
        self.participants = participants
        self.votes = {"hindi": set(), "english": set()}

    @discord.ui.button(label="Hindi Songs 🇮🇳", style=discord.ButtonStyle.secondary)
    async def hindi_vote(self, interaction: discord.Interaction, button: discord.ui.Button):
        if interaction.user.id not in self.participants:
            return await interaction.response.send_message("🚫 Only participants can vote!", ephemeral=True)
        
        if interaction.user.id in self.votes["english"]:
            self.votes["english"].remove(interaction.user.id)
        
        self.votes["hindi"].add(interaction.user.id)
        self.update_labels()
        try:
            await interaction.response.edit_message(view=self)
        except Exception as e:
            logger.warning(f"Vote update failed (network): {e}")

    @discord.ui.button(label="English Songs 🇺🇸", style=discord.ButtonStyle.secondary)
    async def english_vote(self, interaction: discord.Interaction, button: discord.ui.Button):
        if interaction.user.id not in self.participants:
            return await interaction.response.send_message("🚫 Only participants can vote!", ephemeral=True)

        if interaction.user.id in self.votes["hindi"]:
            self.votes["hindi"].remove(interaction.user.id)
            
        self.votes["english"].add(interaction.user.id)
        self.update_labels()
        try:
            await interaction.response.edit_message(view=self)
        except Exception as e:
            logger.warning(f"Vote update failed (network): {e}")

    @discord.ui.button(label="Confirm & Start", style=discord.ButtonStyle.success, row=1)
    async def confirm(self, interaction: discord.Interaction, button: discord.ui.Button):
        if interaction.user.id != self.host_id:
            return await interaction.response.send_message("❌ Only the host can confirm.", ephemeral=True)
        
        self.stop()
        await interaction.response.defer()

    def update_labels(self):
        self.children[0].label = f"Hindi Songs 🇮🇳 ({len(self.votes['hindi'])})"
        self.children[1].label = f"English Songs 🇺🇸 ({len(self.votes['english'])})"

class TriviaJoinView(discord.ui.View):
    def __init__(self, host_id):
        super().__init__(timeout=60)
        self.host_id = host_id
        self.participants = set()
        self.participants.add(host_id) 

    @discord.ui.button(label="Join Game", style=discord.ButtonStyle.success, emoji="🎮")
    async def join(self, interaction: discord.Interaction, button: discord.ui.Button):
        if interaction.user.id in self.participants:
            return await interaction.response.send_message("⚠️ You already joined!", ephemeral=True)
        
        self.participants.add(interaction.user.id)
        await interaction.response.send_message(f"✅ {interaction.user.mention} joined the game!", ephemeral=False)

    @discord.ui.button(label="Next", style=discord.ButtonStyle.primary, emoji="➡️")
    async def start(self, interaction: discord.Interaction, button: discord.ui.Button):
        if interaction.user.id != self.host_id:
            return await interaction.response.send_message("❌ Only the host can proceed.", ephemeral=True)
        
        if not self.participants:
            return await interaction.response.send_message("❌ Need at least 1 player!", ephemeral=True)
            
        self.stop()
        await interaction.response.defer()

class TriviaButton(discord.ui.Button):
    def __init__(self, label_text, is_correct):
        # Clean label for display
        clean_label = label_text.split('(')[0].split('[')[0].strip()[:80]
        super().__init__(label=clean_label, style=discord.ButtonStyle.primary)
        self.label_text = label_text
        self.is_correct = is_correct

    async def callback(self, interaction: discord.Interaction):
        view: TriviaChoiceView = self.view
        if view.winner or view.all_wrong: 
            return

        if interaction.user.id not in view.participants:
            return await interaction.response.send_message("🚫 You didn't join the game during the lobby phase!", ephemeral=True)

        if interaction.user.id in view.guessed_users:
            return await interaction.response.send_message("🚫 You only get **one chance** per round!", ephemeral=True)

        view.guessed_users.add(interaction.user.id)

        if self.is_correct:
            view.winner = interaction.user
            self.style = discord.ButtonStyle.success
            
            # Disable all buttons
            for child in view.children:
                child.disabled = True
                if child != self and child.style != discord.ButtonStyle.danger:
                     child.style = discord.ButtonStyle.secondary
            
            view.stop()
            
            try:
                await interaction.response.edit_message(view=view)
            except Exception as e:
                logger.warning(f"Trivia UI update failed: {e}")
                
            try:
                await interaction.followup.send(f"🎉 **{interaction.user.mention}** got it! The answer was **{self.label_text}**.")
            except: pass
        else:
            # Wrong answer
            self.style = discord.ButtonStyle.danger
            self.disabled = True
            
            try:
                await interaction.response.edit_message(view=view)
            except Exception as e:
                logger.warning(f"Trivia UI update failed: {e}")

            try:
                await interaction.followup.send(f"❌ **{interaction.user.mention}** guessed wrong!", ephemeral=False)
            except: pass
            
            # Check all wrong
            if len(view.guessed_users) >= len(view.participants):
                view.all_wrong = True
                for child in view.children:
                    child.disabled = True
                view.stop()

class TriviaChoiceView(discord.ui.View):
    def __init__(self, correct_text, options_data, participants):
        super().__init__(timeout=25)
        self.winner = None
        self.all_wrong = False
        self.participants = participants
        self.guessed_users = set()
        
        random.shuffle(options_data)
        for text in options_data:
            is_correct = (text == correct_text)
            self.add_item(TriviaButton(text, is_correct))

# --- Speed Control View ---
class SpeedSelect(discord.ui.Select):
    def __init__(self, player: wavelink.Player):
        self.player = player
        options = [
            discord.SelectOption(label="0.5x (Slow Motion)", value="0.5", emoji="🐢"),
            discord.SelectOption(label="0.75x", value="0.75", emoji="🚶"),
            discord.SelectOption(label="1.0x (Normal)", value="1.0", emoji="▶️"),
            discord.SelectOption(label="1.25x (Nightcore)", value="1.25", emoji="🌙"),
            discord.SelectOption(label="1.5x (Fast)", value="1.5", emoji="💨"),
            discord.SelectOption(label="1.75x", value="1.75", emoji="🏎️"),
            discord.SelectOption(label="2.0x (Double Time)", value="2.0", emoji="🚀"),
        ]
        super().__init__(placeholder="Select Playback Speed", min_values=1, max_values=1, options=options)

    async def callback(self, interaction: discord.Interaction):
        speed = float(self.values[0])
        filters = self.player.filters or wavelink.Filters()
        filters.timescale.set(speed=speed)
        await self.player.set_filters(filters)
        try:
            await interaction.response.send_message(f"⏱️ Speed set to **{speed}x**.", ephemeral=True)
        except: pass

class SpeedView(discord.ui.View):
    def __init__(self, player: wavelink.Player):
        super().__init__(timeout=60)
        self.add_item(SpeedSelect(player))

# --- Player Controller View ---
class PlayerControls(discord.ui.View):
    def __init__(self, player: wavelink.Player):
        super().__init__(timeout=None)
        self.player = player

    @discord.ui.button(emoji="⏮️", style=discord.ButtonStyle.secondary, row=0)
    async def prev_button(self, interaction: discord.Interaction, button: discord.ui.Button):
        if not self.player: return
        
        try:
            if len(self.player.queue.history) == 0:
                await self.player.seek(0)
                return await interaction.response.send_message("⏮️ Replaying (No history found).", ephemeral=True)
            
            previous_track = self.player.queue.history[-1]
            del self.player.queue.history[-1]
            
            if self.player.current:
                self.player.queue.put_at(0, self.player.current)

            await self.player.play(previous_track)
            await interaction.response.send_message(f"⏮️ Playing previous: **{previous_track.title}**", ephemeral=True)
        except Exception as e:
            logger.warning(f"Prev Error: {e}")
            try: await interaction.response.send_message("❌ Error going back.", ephemeral=True)
            except: pass

    @discord.ui.button(emoji="⏯️", style=discord.ButtonStyle.primary, row=0)
    async def pause_resume_button(self, interaction: discord.Interaction, button: discord.ui.Button):
        if not self.player: return
        try:
            if self.player.paused:
                await self.player.pause(False)
                button.style = discord.ButtonStyle.primary
            else:
                await self.player.pause(True)
                button.style = discord.ButtonStyle.secondary
            await interaction.response.edit_message(view=self)
        except: pass

    @discord.ui.button(emoji="⏭️", style=discord.ButtonStyle.secondary, row=0)
    async def skip_button(self, interaction: discord.Interaction, button: discord.ui.Button):
        if not self.player: return
        await self.player.skip(force=True)
        try:
            await interaction.response.send_message("⏭️ Skipped.", ephemeral=True)
        except: pass

    @discord.ui.button(emoji="🔁", label="Off", style=discord.ButtonStyle.secondary, row=0)
    async def loop_button(self, interaction: discord.Interaction, button: discord.ui.Button):
        if not self.player: return
        current_mode = self.player.queue.mode
        
        # Cycle: Normal -> Loop Track -> Loop Queue -> Normal
        if current_mode == wavelink.QueueMode.normal:
            self.player.queue.mode = wavelink.QueueMode.loop
            self.player.autoplay = wavelink.AutoPlayMode.disabled # Force Disable Autoplay
            
            button.label = "Track"
            button.emoji = "🔂"
            button.style = discord.ButtonStyle.success
            msg = "🔂 Loop enabled: **Track** (Autoplay Disabled)"
            
        elif current_mode == wavelink.QueueMode.loop:
            self.player.queue.mode = wavelink.QueueMode.loop_all
            self.player.autoplay = wavelink.AutoPlayMode.disabled # Force Disable Autoplay
            
            button.label = "Queue"
            button.emoji = "🔁"
            button.style = discord.ButtonStyle.success
            msg = "🔁 Loop enabled: **Queue** (Autoplay Disabled)"
            
        else:
            self.player.queue.mode = wavelink.QueueMode.normal
            button.label = "Off"
            button.emoji = "➡️"
            button.style = discord.ButtonStyle.secondary
            msg = "➡️ Loop **Disabled**"
        
        try:
            await interaction.response.edit_message(view=self)
            await interaction.followup.send(msg, ephemeral=True)
        except: pass

    @discord.ui.button(emoji="🎚️", style=discord.ButtonStyle.secondary, row=1)
    async def eq_button(self, interaction: discord.Interaction, button: discord.ui.Button):
        if not self.player: return
        await interaction.response.send_message("🎚️ **Equalizer Settings**", view=EqualizerView(self.player), ephemeral=True)

    @discord.ui.button(emoji="⏱️", style=discord.ButtonStyle.secondary, row=1)
    async def speed_button(self, interaction: discord.Interaction, button: discord.ui.Button):
        if not self.player: return
        await interaction.response.send_message("⏱️ **Speed Control**", view=SpeedView(self.player), ephemeral=True)

    @discord.ui.button(emoji="⏹️", style=discord.ButtonStyle.danger, row=1)
    async def stop_button(self, interaction: discord.Interaction, button: discord.ui.Button):
        if not self.player: return
        await self.player.disconnect()
        try:
            await interaction.response.send_message("👋 Disconnected.", ephemeral=True)
        except: pass

# --- Manual EQ View ---
class ManualEQView(discord.ui.View):
    def __init__(self, player: wavelink.Player):
        super().__init__(timeout=60)
        self.player = player
        self.selected_band = 0
        self.band_labels = {
            0: "25 Hz (Sub-Bass)", 1: "40 Hz (Bass)", 2: "63 Hz (Bass)",
            3: "100 Hz (Low-Mid)", 4: "160 Hz (Low-Mid)", 5: "250 Hz (Low-Mid)",
            6: "400 Hz (Mid)", 7: "630 Hz (Mid)", 8: "1 kHz (Mid)",
            9: "1.6 kHz (High-Mid)", 10: "2.5 kHz (High-Mid)", 11: "4 kHz (Treble)",
            12: "6.3 kHz (Treble)", 13: "10 kHz (High-Treble)", 14: "16 kHz (Air)"
        }
        if not hasattr(self.player, 'eq_gains'):
            self.player.eq_gains = {i: 0.0 for i in range(15)}
        self.select_menu = discord.ui.Select(placeholder="Select Frequency Band", min_values=1, max_values=1)
        for i in range(15):
            self.select_menu.add_option(label=self.band_labels[i], value=str(i))
        self.select_menu.callback = self.band_select_callback
        self.add_item(self.select_menu)

    async def band_select_callback(self, interaction: discord.Interaction):
        self.selected_band = int(self.select_menu.values[0])
        await self.update_embed(interaction)

    async def update_embed(self, interaction):
        current_gain = self.player.eq_gains.get(self.selected_band, 0.0)
        embed = discord.Embed(title="🎛️ Manual Equalizer", color=discord.Color.blurple())
        embed.description = (
            f"**Target Band:** `{self.band_labels[self.selected_band]}`\n"
            f"**Current Gain:** `{current_gain:.2f}`\n\n"
            "Use buttons below to adjust gain."
        )
        try:
            await interaction.response.edit_message(embed=embed, view=self)
        except: pass

    async def adjust_gain(self, interaction, delta):
        current_gain = self.player.eq_gains.get(self.selected_band, 0.0)
        new_gain = max(-0.25, min(1.0, current_gain + delta))
        self.player.eq_gains[self.selected_band] = new_gain
        filters = self.player.filters or wavelink.Filters()
        bands_payload = [{'band': b, 'gain': g} for b, g in self.player.eq_gains.items()]
        filters.equalizer.set(bands=bands_payload)
        await self.player.set_filters(filters)
        await self.update_embed(interaction)

    @discord.ui.button(label="-", style=discord.ButtonStyle.primary)
    async def decrease_gain(self, interaction: discord.Interaction, button: discord.ui.Button):
        await self.adjust_gain(interaction, -0.05)

    @discord.ui.button(label="Reset Band", style=discord.ButtonStyle.secondary)
    async def reset_band(self, interaction: discord.Interaction, button: discord.ui.Button):
        self.player.eq_gains[self.selected_band] = 0.0
        filters = self.player.filters or wavelink.Filters()
        bands_payload = [{'band': b, 'gain': g} for b, g in self.player.eq_gains.items()]
        filters.equalizer.set(bands=bands_payload)
        await self.player.set_filters(filters)
        await self.update_embed(interaction)

    @discord.ui.button(label="+", style=discord.ButtonStyle.primary)
    async def increase_gain(self, interaction: discord.Interaction, button: discord.ui.Button):
        await self.adjust_gain(interaction, 0.05)

    @discord.ui.button(label="Back to Presets", style=discord.ButtonStyle.grey, row=2)
    async def back_button(self, interaction: discord.Interaction, button: discord.ui.Button):
        try:
            await interaction.response.edit_message(content="🎚️ **Equalizer Settings**", embeds=[], view=EqualizerView(self.player))
        except Exception as e:
            logger.error(f"Back button failed: {e}")
            try:
                await interaction.response.send_message("🎚️ **Equalizer Settings**", view=EqualizerView(self.player), ephemeral=True)
            except: pass

# --- Equalizer Presets View ---
class EqualizerSelect(discord.ui.Select):
    def __init__(self, player: wavelink.Player):
        self.player = player
        options = [
            discord.SelectOption(label="Flat / Reset", description="Reset all audio effects", emoji="✨", value="flat"),
            discord.SelectOption(label="8D Audio", description="Spatial rotation effect", emoji="🌀", value="8d"),
            discord.SelectOption(label="Karaoke", description="Remove vocals for singing", emoji="🎤", value="karaoke"),
            discord.SelectOption(label="Bass Boost", description="Heavy low-end boost", emoji="🥁", value="bass"),
            discord.SelectOption(label="Nightcore", description="Speed up and higher pitch", emoji="🌙", value="nightcore"),
            discord.SelectOption(label="Vaporwave", description="Slow down and lower pitch", emoji="🌊", value="vaporwave"),
            discord.SelectOption(label="Pop", description="Boosts vocals and brightness", emoji="🎈", value="pop"),
            discord.SelectOption(label="Gaming", description="Explosive sound, footsteps clarity", emoji="🎮", value="gaming"),
        ]
        super().__init__(placeholder="🎚️ Select Audio Effect...", min_values=1, max_values=1, options=options)

    async def callback(self, interaction: discord.Interaction):
        # Initialize filters
        filters = self.player.filters or wavelink.Filters()
        val = self.values[0]
        msg = ""

        # Reset all filters first to prevent conflict
        filters.reset() 
        self.player.eq_gains = {i: 0.0 for i in range(15)} # Reset manual EQ tracking

        if val == "flat":
            msg = "✨ **Audio Effects Cleared**"

        elif val == "8d":
            # 8D Audio: Uses Rotation
            filters.rotation.set(rotation_hz=0.2)
            msg = "🌀 **8D Audio Enabled** (Headphones recommended!)"

        elif val == "karaoke":
            # Karaoke: Suppress center channel (vocals)
            # Adjust level and filter_band as needed
            filters.karaoke.set(level=1.0, mono_level=1.0, filter_band=220.0, filter_width=100.0)
            msg = "🎤 **Karaoke Mode Enabled** (Vocals Removed)"

        elif val == "bass":
            bands = [{'band': 0, 'gain': 0.4}, {'band': 1, 'gain': 0.35}, {'band': 2, 'gain': 0.3}, {'band': 3, 'gain': 0.2}, {'band': 4, 'gain': 0.1}]
            filters.equalizer.set(bands=bands)
            msg = "🥁 **Bass Boost Enabled**"

        elif val == "nightcore":
            filters.timescale.set(pitch=1.2, speed=1.1)
            msg = "🌙 **Nightcore Enabled**"

        elif val == "vaporwave":
            filters.timescale.set(pitch=0.8, speed=0.85)
            msg = "🌊 **Vaporwave Enabled**"

        elif val == "pop":
            bands = [{'band': 6, 'gain': 0.1}, {'band': 7, 'gain': 0.1}, {'band': 8, 'gain': 0.1}, {'band': 9, 'gain': 0.1}, {'band': 10, 'gain': 0.1}, {'band': 11, 'gain': 0.1}]
            filters.equalizer.set(bands=bands)
            msg = "🎈 **Pop Mode Enabled**"

        elif val == "gaming":
            bands = [{'band': 0, 'gain': 0.2}, {'band': 1, 'gain': 0.15}, {'band': 12, 'gain': 0.15}, {'band': 13, 'gain': 0.2}, {'band': 14, 'gain': 0.2}]
            filters.equalizer.set(bands=bands)
            msg = "🎮 **Gaming Mode Enabled**"
        
        await self.player.set_filters(filters)
        
        try:
            await interaction.response.send_message(msg, ephemeral=True)
        except: pass

class EqualizerView(discord.ui.View):
    def __init__(self, player: wavelink.Player):
        super().__init__(timeout=60)
        self.player = player
        self.add_item(EqualizerSelect(player))

    @discord.ui.button(label="🎛️ Manual Adjustment", style=discord.ButtonStyle.primary, row=1)
    async def manual_eq(self, interaction: discord.Interaction, button: discord.ui.Button):
        embed = discord.Embed(title="🎛️ Manual Equalizer", description="Select a frequency band below to adjust.", color=discord.Color.blurple())
        try:
            await interaction.response.edit_message(content=None, embed=embed, view=ManualEQView(self.player))
        except: pass

# --- GAME STATE CLASS ---
class GameState:
    def __init__(self, rounds):
        self.rounds = rounds
        self.current_round = 0
        self.scores = {}
        self.active = True

# --- Custom Bot Class ---
class LavaBot(commands.AutoShardedBot):
    def __init__(self):
        intents = discord.Intents.default()
        intents.message_content = True 
        super().__init__(
            command_prefix=self.get_custom_prefix,
            intents=intents,
            help_command=None, 
            activity=discord.Activity(type=discord.ActivityType.listening, name="/play | m!help")
        )

    async def get_custom_prefix(self, bot, message):
        if not message.guild:
            return commands.when_mentioned_or("m!")(bot, message)
        prefix = db.get_prefix(message.guild.id)
        return commands.when_mentioned_or(prefix)(bot, message)

    async def setup_hook(self):
        nodes = [wavelink.Node(uri=LAVALINK_URI, password=LAVALINK_PASS, identifier=LAVALINK_IDENTIFIER)]
        await wavelink.Pool.connect(nodes=nodes, client=self, cache_capacity=100)
        logger.info("Bot setup complete. Nodes connected.")

    async def on_ready(self):
        logger.info(f"Logged in as {self.user} (ID: {self.user.id})")
        logger.info(f"Shards: {self.shard_count}")

    async def on_message(self, message):
        if message.author.bot:
            return

        # Check if bot is mentioned specifically (ignoring replies/mass mentions)
        if self.user.mentioned_in(message) and not message.mention_everyone:
             # Clean the message content to see if it's just the mention
             # Handles <@ID> and <@!ID>
             content = message.content.replace(f'<@!{self.user.id}>', '').replace(f'<@{self.user.id}>', '').strip()
             
             if not content: # Content is empty after removing mention -> User just tagged the bot
                 prefix = db.get_prefix(message.guild.id) if message.guild else "m!"
                 
                 embed = discord.Embed(
                     title="👋 Hi there! I'm Moody Music",
                     description="I'm your all-in-one Music & Trivia bot. Here's how to use me:",
                     color=discord.Color.from_rgb(138, 43, 226)
                 )
                 
                 embed.set_thumbnail(url=self.user.display_avatar.url)
                 
                 embed.add_field(
                     name="🎵 **Play Music**", 
                     value=f"• Join a voice channel.\n• Type `/play <song name>` or `{prefix}play <url>`.\n• Use the player buttons to pause, skip, or loop.",
                     inline=False
                 )
                 
                 embed.add_field(
                     name="🎮 **Play Games**", 
                     value=f"• Type `/games` (or `{prefix}games`) to start.\n• Choose **Song Trivia** or **Bollywood Movie Guess**.\n• Compete with friends to guess correctly!",
                     inline=False
                 )
                 
                 embed.add_field(
                     name="⚙️ **Effects & Settings**", 
                     value=f"• Type `/eq` for **8D Audio**, **Karaoke**, and **Bass Boost**.\n• Type `/speed` to change tempo.\n• Type `/autoplay` to toggle auto-recommendations.\n• Current Prefix: `{prefix}`",
                     inline=False
                 )
                 
                 embed.set_footer(text=f"Type {prefix}help for the full command list.")
                 
                 try:
                    await message.channel.send(embed=embed)
                 except:
                    pass

        await self.process_commands(message)

# --- Music Logic (Cog) ---
class Music(commands.Cog):
    def __init__(self, bot):
        self.bot = bot
        self.trivia_games: Dict[int, GameState] = {} 

    @commands.Cog.listener()
    async def on_wavelink_node_ready(self, payload: wavelink.NodeReadyEventPayload):
        logger.info(f"Wavelink Node connected: {payload.node.identifier} | Res: {payload.resumed}")

    @commands.Cog.listener()
    async def on_wavelink_track_start(self, payload: wavelink.TrackStartEventPayload):
        player = payload.player
        if not player: return
        # Check guild-specific trivia state
        if player.guild.id in self.trivia_games and self.trivia_games[player.guild.id].active: 
            return 

        track = payload.track
        embed = discord.Embed(title="Now Playing", description=f"🎵 **[{track.title}]({track.uri})**", color=discord.Color.from_rgb(138, 43, 226))
        
        artwork = track.artwork
        if not artwork and track.source == "youtube":
            artwork = f"https://img.youtube.com/vi/{track.identifier}/maxresdefault.jpg"
        elif not artwork and "youtube.com" in track.uri:
             artwork = f"https://img.youtube.com/vi/{track.identifier}/maxresdefault.jpg"

        if artwork:
            embed.set_image(url=artwork)
        else:
            embed.set_thumbnail(url=self.bot.user.display_avatar.url)
            
        embed.add_field(name="Artist", value=track.author, inline=True)
        
        duration_sec = track.length / 1000
        minutes = int(duration_sec // 60)
        seconds = int(duration_sec % 60)
        embed.add_field(name="Duration", value=f"{minutes:02d}:{seconds:02d}", inline=True)

        channel = getattr(player, 'text_channel', None)
        if channel:
            old_msg = getattr(player, 'controller_message', None)
            if old_msg:
                try:
                    await old_msg.edit(embed=embed, view=PlayerControls(player))
                    return 
                except:
                    # Message likely deleted or missing, clear it so we send a new one below
                    player.controller_message = None
                    pass
            
            try:
                msg = await channel.send(embed=embed, view=PlayerControls(player))
                player.controller_message = msg
            except Exception as e:
                logger.error(f"Failed to send controller: {e}")

    @commands.Cog.listener()
    async def on_wavelink_track_end(self, payload: wavelink.TrackEndEventPayload):
        player = payload.player
        if not player: return

        if payload.reason == "REPLACED":
            return
        
        # --- RATE LIMIT FIX: Do NOT delete the old message here. 
        # We let on_wavelink_track_start edit it.
        # Only delete if we are truly stopping/empty.

        # EXPLICIT LOOP & AUTOPLAY LOGIC
        try:
            if player.queue.mode == wavelink.QueueMode.loop:
                # 1. Single Song Loop
                # Replay the EXACT SAME track immediately
                await player.play(payload.track)
                return
            
            elif player.queue.mode == wavelink.QueueMode.loop_all:
                # 2. Playlist Loop
                # Put the finished track at the back of the queue
                await player.queue.put_wait(payload.track)
                # Then play the next one from the front
                next_track = player.queue.get()
                await player.play(next_track)

            else:
                # 3. Normal / Autoplay
                # If Autoplay is enabled, Wavelink automatically populates queue before get() raises Empty
                next_track = player.queue.get()
                await player.play(next_track)
        
        except wavelink.QueueEmpty:
            # 4. Queue is genuinely empty
            # If Autoplay is enabled but failed to populate (rare), or if disabled:
            # Check 24/7 mode
            is_247 = db.get_247_status(player.guild.id)
            if not is_247:
                await asyncio.sleep(180) 
                if player.connected and player.queue.is_empty and not player.playing:
                    # Cleanup message ONLY when disconnecting
                    old_msg = getattr(player, 'controller_message', None)
                    if old_msg:
                        try: await old_msg.delete()
                        except: pass
                    await player.disconnect()

    @commands.command(name="sync")
    @commands.has_permissions(administrator=True)
    async def sync_commands(self, ctx):
        msg = await ctx.send("🔄 Syncing commands...")
        await self.bot.tree.sync()
        await msg.edit(content="✅ Slash commands synced!")

    @commands.hybrid_command(name="stats")
    async def stats_command(self, ctx: commands.Context):
        """Shows bot statistics."""
        server_count = len(self.bot.guilds)
        player_count = len(self.bot.voice_clients)
        await ctx.send(f"📊 **Bot Stats**\nServers: {server_count}\nActive Players: {player_count}")

    @commands.hybrid_command(name="help", description="Show the list of available commands.")
    async def help_command(self, ctx: commands.Context):
        prefix = db.get_prefix(ctx.guild.id) if ctx.guild else "m!"
        embed = discord.Embed(title="🎵 Moody Music Bot Help", color=discord.Color.from_rgb(138, 43, 226))
        
        embed.add_field(name="🎧 Music Commands", value=(
            f"`{prefix}join`\nJoins your voice channel.\n"
            f"`{prefix}play <query>`\nPlays song.\n"
            f"`{prefix}autoplay`\n**Auto-play related songs.**\n"
            f"`{prefix}replay`\nReplay current song.\n"
            f"`{prefix}loop`\nCycle loop modes.\n"
            f"`{prefix}eq`\nEqualizer & Effects.\n"
            f"`{prefix}speed [val]`\n**Speed/Tempo Control.**\n"
            f"`{prefix}lyrics [query]`\nGet song lyrics.\n"
            f"`{prefix}current`\nShow current song details."
        ), inline=False)
        
        embed.add_field(name="🎮 Games", value=(
            f"`{prefix}games`\n**Play Song or Movie Trivia!**\n"
            f"`{prefix}trivia stop`\nEnd the game."
        ), inline=False)

        embed.add_field(name="⚙️ Admin Commands", value=f"`{prefix}247` | `{prefix}prefix` | `{prefix}sync`", inline=False)
        await ctx.send(embed=embed)

    @commands.hybrid_command(name="current", aliases=["np", "nowplaying"])
    async def current(self, ctx: commands.Context):
        """Shows details of the currently playing song."""
        await ctx.defer()
        vc: wavelink.Player = ctx.voice_client
        if not vc or not vc.current:
            return await ctx.send("❌ Nothing is currently playing.")
        
        track = vc.current
        
        embed = discord.Embed(
            title="Now Playing",
            description=f"🎵 **[{track.title}]({track.uri})**",
            color=discord.Color.from_rgb(138, 43, 226)
        )
        
        artwork = track.artwork
        if not artwork and track.source == "youtube":
            artwork = f"https://img.youtube.com/vi/{track.identifier}/maxresdefault.jpg"
        elif not artwork and "youtube.com" in track.uri:
             artwork = f"https://img.youtube.com/vi/{track.identifier}/maxresdefault.jpg"

        if artwork:
            embed.set_image(url=artwork)
        
        embed.add_field(name="Artist", value=track.author, inline=True)
        
        position = vc.position / 1000
        length = track.length / 1000
        
        pos_m = int(position // 60)
        pos_s = int(position % 60)
        len_m = int(length // 60)
        len_s = int(length % 60)
        
        embed.add_field(name="Time", value=f"{pos_m:02d}:{pos_s:02d} / {len_m:02d}:{len_s:02d}", inline=True)
        
        total_bars = 20
        progress = int((position / length) * total_bars) if length > 0 else 0
        bar = "▬" * progress + "🔘" + "▬" * (total_bars - progress)
        embed.add_field(name="Progress", value=f"`{bar}`", inline=False)
        
        await ctx.send(embed=embed)

    # --- GAMES COMMAND ---
    @commands.hybrid_command(name="games", aliases=["game"])
    async def games_command(self, ctx, argument: str = "5"):
        """Opens the game selection menu. Usage: /games [rounds] or /games stop"""
        # 1. Handle "stop" argument gracefully
        if argument.lower() == "stop":
            return await self._stop_game_logic(ctx)

        # 2. Try to convert argument to integer for rounds
        try:
            rounds = int(argument)
        except ValueError:
            return await ctx.send(f"❌ Invalid argument `{argument}`. Please enter a number for rounds (e.g. `/games 10`) or type `/games stop`.", ephemeral=True)

        if rounds < 1:
            return await ctx.send("❌ Rounds must be at least 1.", ephemeral=True)

        view = GameSelectionView(ctx)
        await ctx.send(f"🎮 **Select a Game Mode** (Rounds: {rounds}):", view=view)
        await view.wait()

        if view.value == "song":
            await self.trivia_start(ctx, rounds=rounds, mode="song")
        elif view.value == "movie":
            await self.trivia_start(ctx, rounds=rounds, mode="movie")
        else:
            try:
                await ctx.send("❌ Selection timed out or cancelled.", ephemeral=True)
            except: pass

    # --- TRIVIA LOGIC ---
    @commands.group(name="trivia", invoke_without_command=True)
    async def trivia(self, ctx):
        await ctx.send("❓ Usage: `/games` to start playing or `/trivia stop`")

    # Helper function to handle stopping games (avoids code duplication)
    async def _stop_game_logic(self, ctx):
        guild_id = ctx.guild.id
        if guild_id not in self.trivia_games or not self.trivia_games[guild_id].active:
            return await ctx.send("❌ No trivia game is currently running.")
        
        game = self.trivia_games[guild_id]
        game.active = False
        if ctx.voice_client:
            await ctx.voice_client.stop()
        
        if game.scores:
            winner_id = max(game.scores, key=game.scores.get)
            score = game.scores[winner_id]
            await ctx.send(f"🛑 **Trivia Ended!**\n🏆 **Winner:** <@{winner_id}> with **{score}** points!")
        else:
            await ctx.send("🛑 **Trivia Ended!** No winners this time.")
            
        del self.trivia_games[guild_id]

    @trivia.command(name="stop")
    async def trivia_stop(self, ctx):
        await self._stop_game_logic(ctx)

    async def trivia_start(self, ctx, rounds: int = 5, mode: str = "song"):
        guild_id = ctx.guild.id
        if guild_id in self.trivia_games:
            return await ctx.send("❌ A game is already running! Stop it first.")
        
        self.trivia_games[guild_id] = GameState(rounds)

        if not ctx.author.voice:
            del self.trivia_games[guild_id]
            return await ctx.send("🚫 You must be in a voice channel.")

        if not ctx.voice_client:
            try:
                vc: wavelink.Player = await ctx.author.voice.channel.connect(cls=wavelink.Player, self_deaf=True)
            except:
                del self.trivia_games[guild_id]
                return await ctx.send("❌ Could not connect.")
        else:
            vc: wavelink.Player = ctx.voice_client
            if vc.channel.id != ctx.author.voice.channel.id:
                await vc.move_to(ctx.author.voice.channel)

        # 1. LOBBY PHASE
        join_view = TriviaJoinView(ctx.author.id)
        mode_title = "Identify the BOLLYWOOD MOVIE 🎬" if mode == "movie" else "Music Trivia 🎵"
        await ctx.send(f"🎮 **{mode_title}**\nClick below to join!", view=join_view)
        await join_view.wait()
        
        if not join_view.participants:
            del self.trivia_games[guild_id]
            return await ctx.send("❌ Lobby cancelled.")
        
        participants = join_view.participants

        # 2. API & DATA SETUP
        HINDI_API = "https://itunes.apple.com/in/rss/topsongs/limit=100/genre=1263/json"
        ENGLISH_API = "https://itunes.apple.com/us/rss/topsongs/limit=100/json"
        
        api_urls = []
        if mode == "movie":
            api_urls = [HINDI_API]
            await ctx.send(f"🎬 **Starting Bollywood Movie Guessing Game!**")
        else:
            vote_view = TriviaVoteView(ctx.author.id, participants)
            await ctx.send(f"🗳️ **Vote for Music Category!**", view=vote_view)
            await vote_view.wait()
            
            if len(vote_view.votes['hindi']) > len(vote_view.votes['english']):
                api_urls = [HINDI_API]
            elif len(vote_view.votes['english']) > len(vote_view.votes['hindi']):
                api_urls = [ENGLISH_API]
            else:
                api_urls = [ENGLISH_API, HINDI_API]

        game = self.trivia_games[guild_id]
        question_bank = []

        async with aiohttp.ClientSession() as session:
            for url in api_urls:
                try:
                    async with session.get(url) as resp:
                        if resp.status == 200:
                            data = await resp.json(content_type=None)
                            entries = data.get('feed', {}).get('entry', [])
                            for entry in entries:
                                title = entry.get('im:name', {}).get('label')
                                artist = entry.get('im:artist', {}).get('label')
                                album = entry.get('im:collection', {}).get('im:name', {}).get('label')

                                if mode == "movie":
                                    if title and artist and album:
                                        question_bank.append({
                                            'answer': album, 
                                            'display': album, 
                                            'query': f"{title} {artist}", 
                                            'meta': f"Song: {title}"
                                        })
                                else:
                                    if title and artist:
                                        question_bank.append({
                                            'answer': title, 
                                            'display': title,
                                            'query': f"ytsearch:{title} {artist}",
                                            'meta': artist
                                        })
                except Exception as e:
                    logger.error(f"API Error: {e}")

        if not question_bank:
            del self.trivia_games[guild_id]
            return await ctx.send("❌ Could not load questions.")

        random.shuffle(question_bank)

        # 3. GAME LOOP
        while game.active and game.current_round < game.rounds:
            game.current_round += 1
            if not question_bank: break
            
            q_data = question_bank.pop()
            correct_answer = q_data['answer']
            
            distractors = []
            attempts = 0
            req_options = min(5, len(participants) + 3)
            
            while len(distractors) < (req_options - 1) and attempts < 100:
                d = random.choice(question_bank)
                d_ans = d['answer']
                if d_ans != correct_answer and d_ans not in distractors:
                    distractors.append(d_ans)
                attempts += 1
            
            options = [correct_answer] + distractors
            
            try:
                if mode == "movie":
                     search_q = f"ytsearch:{q_data['query']}"
                else:
                     search_q = q_data['query']

                tracks = await wavelink.Playable.search(search_q)
                if tracks:
                    await vc.play(tracks[0])
                else:
                    await ctx.send("⚠️ Audio unavailable, skipping round.")
                    continue
            except:
                continue

            prompt = f"🎬 **Round {game.current_round}: Which MOVIE is this song from?**" if mode == "movie" else f"🎵 **Round {game.current_round}: Guess the Song!**"
            
            view = TriviaChoiceView(correct_answer, options, participants)
            await ctx.send(prompt, view=view)
            await view.wait()

            if view.winner:
                game.scores[view.winner.id] = game.scores.get(view.winner.id, 0) + 1
                if game.scores[view.winner.id] >= 5:
                    await ctx.send(f"🏆 **<@{view.winner.id}> WINS THE GAME!**")
                    game.active = False
                    break
            elif view.all_wrong:
                await ctx.send(f"💀 **Wrong!** It was **{correct_answer}**.")
            else:
                await ctx.send(f"⏰ Time's up! It was **{correct_answer}**.")

            await asyncio.sleep(4)

        if game.active:
            await self.trivia_stop(ctx)

    @commands.hybrid_command(name="join", aliases=["j", "connect"])
    async def join(self, ctx: commands.Context):
        await ctx.defer()
        if not ctx.guild: return
        if not ctx.author.voice: return await ctx.send("🚫 You must be in a voice channel.")
        if ctx.voice_client: return await ctx.send("❌ Already connected.")

        try:
            vc: wavelink.Player = await ctx.author.voice.channel.connect(cls=wavelink.Player, self_deaf=True)
            vc.autoplay = wavelink.AutoPlayMode.partial
            vc.text_channel = ctx.channel
            await ctx.send(f"✅ Joined **{ctx.author.voice.channel.name}**.")
        except Exception as e:
            await ctx.send(f"❌ Could not connect: {e}")

    @commands.hybrid_command(name="lyrics")
    async def lyrics(self, ctx: commands.Context, *, query: str = None):
        await ctx.defer()
        vc: wavelink.Player = ctx.voice_client
        if not query:
            if vc and vc.playing:
                query = f"{vc.current.title} {vc.current.author}"
            else:
                return await ctx.send("❌ No song playing. Please specify a song.")

        async with aiohttp.ClientSession() as session:
            try:
                url = "https://lrclib.net/api/search"
                params = {"q": query}
                async with session.get(url, params=params) as resp:
                    if resp.status != 200: return await ctx.send("❌ API Error.")
                    data = await resp.json()
                    if not data: return await ctx.send("❌ No lyrics found.")
                    
                    song_data = data[0]
                    lyrics_text = song_data.get("plainLyrics") or "Lyrics unavailable."
                    if len(lyrics_text) > 4000: lyrics_text = lyrics_text[:4000] + "..."
                    
                    embed = discord.Embed(title=f"🎤 Lyrics: {song_data.get('trackName')}", description=lyrics_text, color=discord.Color.blue())
                    await ctx.send(embed=embed)
            except Exception as e:
                await ctx.send(f"❌ Error: {e}")

    @commands.hybrid_command(name="play", aliases=["p"])
    async def play(self, ctx: commands.Context, *, query: str):
        await ctx.defer()
        if self.trivia_games.get(ctx.guild.id) and self.trivia_games[ctx.guild.id].active:
             return await ctx.send("❌ Trivia is running! Use `/trivia stop` first.")
        if not ctx.guild: return
        if not ctx.author.voice: return await ctx.send("🚫 Join a voice channel first.")

        if not ctx.voice_client:
            try:
                vc: wavelink.Player = await ctx.author.voice.channel.connect(cls=wavelink.Player, self_deaf=True)
                vc.autoplay = wavelink.AutoPlayMode.partial
                vc.text_channel = ctx.channel
            except Exception as e: return await ctx.send(f"❌ Connect Error: {e}")
        else:
            vc: wavelink.Player = ctx.voice_client
            vc.text_channel = ctx.channel 

        try:
            tracks = await wavelink.Playable.search(query)
        except Exception as e: return await ctx.send(f"❌ Search Error: {e}")

        if not tracks: return await ctx.send("❌ No tracks found.")

        if isinstance(tracks, wavelink.Playlist):
            added = await vc.queue.put_wait(tracks)
            embed = discord.Embed(title="Playlist Added", description=f"✅ Added **{added}** tracks.", color=discord.Color.green())
        else:
            track = tracks[0]
            await vc.queue.put_wait(track)
            embed = discord.Embed(title="Track Added", description=f"✅ Added **[{track.title}]({track.uri})**", color=discord.Color.blurple())

        if not vc.playing:
            await vc.play(vc.queue.get())
        
        await ctx.send(embed=embed)

    @commands.hybrid_command(name="replay")
    async def replay(self, ctx: commands.Context):
        vc: wavelink.Player = ctx.voice_client
        if not vc or not vc.playing: return await ctx.send("❌ Nothing playing.")
        await vc.seek(0)
        await ctx.send("⏮️ Replaying track.")

    @commands.hybrid_command(name="loop")
    async def loop(self, ctx: commands.Context, mode: str = None):
        vc: wavelink.Player = ctx.voice_client
        if not vc: return await ctx.send("❌ Not connected.")
        
        if not mode:
            if vc.queue.mode == wavelink.QueueMode.normal:
                vc.queue.mode = wavelink.QueueMode.loop
                vc.autoplay = wavelink.AutoPlayMode.disabled
                await ctx.send("🔂 Loop: **Track** (Autoplay Disabled)")
            elif vc.queue.mode == wavelink.QueueMode.loop:
                vc.queue.mode = wavelink.QueueMode.loop_all
                vc.autoplay = wavelink.AutoPlayMode.disabled
                await ctx.send("🔁 Loop: **Queue** (Autoplay Disabled)")
            else:
                vc.queue.mode = wavelink.QueueMode.normal
                await ctx.send("➡️ Loop: **Disabled**")
        else:
            mode = mode.lower()
            if mode in ["track", "song", "1"]:
                vc.queue.mode = wavelink.QueueMode.loop
                vc.autoplay = wavelink.AutoPlayMode.disabled
                await ctx.send("🔂 Loop: **Track** (Autoplay Disabled)")
            elif mode in ["queue", "all"]:
                vc.queue.mode = wavelink.QueueMode.loop_all
                vc.autoplay = wavelink.AutoPlayMode.disabled
                await ctx.send("🔁 Loop: **Queue** (Autoplay Disabled)")
            elif mode in ["off", "disable", "none"]:
                vc.queue.mode = wavelink.QueueMode.normal
                await ctx.send("➡️ Loop: **Disabled**")
            else:
                await ctx.send("❌ Options: `track`, `queue`, `off`")

    @commands.hybrid_command(name="skip", aliases=["s", "next"])
    async def skip(self, ctx: commands.Context):
        vc: wavelink.Player = ctx.voice_client
        if not vc or not vc.playing: return await ctx.send("❌ Nothing playing.")
        await vc.skip(force=True)
        await ctx.send("⏭️ Skipped.")

    @commands.hybrid_command(name="stop", aliases=["leave", "dc"])
    async def stop(self, ctx: commands.Context):
        vc: wavelink.Player = ctx.voice_client
        if not vc: return await ctx.send("❌ Not connected.")
        await vc.disconnect()
        # Manually cleanup here because we're stopping forcefully
        old_msg = getattr(vc, 'controller_message', None)
        if old_msg:
             try: await old_msg.delete()
             except: pass
        await ctx.send("👋 Disconnected.")

    @commands.hybrid_command(name="volume", aliases=["vol"])
    async def volume(self, ctx: commands.Context, volume: int):
        vc: wavelink.Player = ctx.voice_client
        if not vc: return
        await vc.set_volume(max(0, min(1000, volume)))
        await ctx.send(f"🔊 Volume set to **{volume}%**")

    @commands.hybrid_command(name="autoplay")
    async def autoplay(self, ctx: commands.Context):
        """Toggles autoplay to automatically play related songs."""
        vc: wavelink.Player = ctx.voice_client
        if not vc: return await ctx.send("❌ Not connected.")

        if vc.autoplay == wavelink.AutoPlayMode.enabled:
            vc.autoplay = wavelink.AutoPlayMode.disabled
            await ctx.send("🛑 **Autoplay Disabled.**")
        else:
            vc.autoplay = wavelink.AutoPlayMode.enabled
            vc.queue.mode = wavelink.QueueMode.normal # Disable loop
            await ctx.send("♾️ **Autoplay Enabled** - Loop disabled.")

    @commands.hybrid_command(name="eq", aliases=["equalizer", "filter"])
    async def equalizer(self, ctx: commands.Context):
        vc: wavelink.Player = ctx.voice_client
        if not vc: return await ctx.send("❌ Not connected.")
        await ctx.send("🎚️ **Equalizer Settings**", view=EqualizerView(vc))

    @commands.hybrid_command(name="speed", aliases=["tempo"])
    async def speed(self, ctx: commands.Context, value: float = None):
        """Sets the playback speed (0.5x - 2.0x)."""
        vc: wavelink.Player = ctx.voice_client
        if not vc: return await ctx.send("❌ Not connected.")

        if value is None:
            return await ctx.send("⏱️ **Speed Control**", view=SpeedView(vc))

        if not 0.5 <= value <= 2.0:
            return await ctx.send("❌ Speed must be between 0.5 and 2.0.")

        filters = vc.filters or wavelink.Filters()
        filters.timescale.set(speed=value)
        await vc.set_filters(filters)
        await ctx.send(f"⏱️ Speed set to **{value}x**.")

    @commands.hybrid_command(name="247")
    @commands.has_permissions(administrator=True)
    async def toggle_247(self, ctx: commands.Context):
        current = db.get_247_status(ctx.guild.id)
        db.set_247_status(ctx.guild.id, not current)
        status_str = "Enabled" if not current else "Disabled"
        await ctx.send(f"🔄 24/7 Mode **{status_str}**.")

    @commands.hybrid_command(name="prefix")
    @commands.has_permissions(administrator=True)
    async def set_guild_prefix(self, ctx: commands.Context, new_prefix: str):
        if len(new_prefix) > 5: return await ctx.send("❌ Prefix too long.")
        db.set_prefix(ctx.guild.id, new_prefix)
        await ctx.send(f"✅ Prefix changed to `{new_prefix}`.")

if __name__ == "__main__":
    bot = LavaBot()
    
    async def main():
        async with bot:
            await bot.add_cog(Music(bot))
            await bot.start(TOKEN)

    if not TOKEN:
        print("Error: DISCORD_TOKEN not found in environment variables.")
    else:
        try:
            asyncio.run(main())
        except KeyboardInterrupt:
            pass